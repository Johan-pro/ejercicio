package ejercicio;

import java.util.Scanner;

public class Siglo {
	public static int siglo(int año) {
        if (año <= 0) {
        	System.out.println("El año debe ser positivo.");
        	 System.exit(0);  
        }
        return (año + 99) / 100;
    }
    public static int primerAno(int siglo) {
        if (siglo <= 0) {
        }
        return (siglo - 1) * 100 + 1;
    }
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce un año: ");
        int año = scanner.nextInt();  
        int siglo = siglo(año);
        System.out.println("El siglo al que pertenece el año " + año + " es el siglo " + siglo);
        scanner.close();
    }
}